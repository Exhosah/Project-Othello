Terms and conditions:

Thanks for downloading template from template.net

Please read more about the product in product overview on website.

We are not liable for the misuse of the resources we provide you. They can be customized and modified to fit your requirements.
 
Redistribution, resells, lease, license, sub-license or offering our resources to third party is not allowed. This includes uploading our resources to another website and offering our resources as a separate attachment from any of your work.

All our resources can be used by you or by the clients you purchase it for.

Some images are taken from unsplash.com and pixabay.com, which are commercial free.
